﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SudokuGenerator.Controllers
{
    public class ValidationController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Standard()
        {
            return View();
        }
    }
}
