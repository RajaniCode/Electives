﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace SudokuGenerator.Models
{
    public class Person
    {
        [Required]
        [StringLength(10)]
        public string first { get; set; }
        [Required]
        public string last { get; set; }
        [Required]
        public string email { get; set; }
        [Required]
        public string mobile { get; set; }
    }
}