﻿/*
* Created By Shemeer NS 
* This Code is created for demo purpose and uploaded in Codeproject
* My Other Articles in codeproject - http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=3175840
* */
using System;
using System.Collections.Generic;

using System.Web;

namespace EditableGridView.egClass
{
    public class EmployeeInfo
    {

        private Int64 _ID;

        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private string _EmployeeCode;

        public string EmployeeCode
        {
            get { return _EmployeeCode; }
            set { _EmployeeCode = value; }
        }

        private string _EmployeeName;

        public string EmployeeName
        {
            get { return _EmployeeName; }
            set { _EmployeeName = value; }
        }

        private Int32 _DepartmentId;

        public Int32 DepartmentId
        {
            get { return _DepartmentId; }
            set { _DepartmentId = value; }
        }

        private string _DepartmentName;

        public string DepartmentName
        {
            get { return _DepartmentName; }
            set { _DepartmentName = value; }
        }
        private string _EmployeeGroup;

        public string EmployeeGroup
        {
            get { return _EmployeeGroup; }
            set { _EmployeeGroup = value; }
        }
        private string _Email;
        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        private bool _isActive;

        public bool isActive
        {
            get { return _isActive; }
            set { _isActive = value; }
        }

    }
}