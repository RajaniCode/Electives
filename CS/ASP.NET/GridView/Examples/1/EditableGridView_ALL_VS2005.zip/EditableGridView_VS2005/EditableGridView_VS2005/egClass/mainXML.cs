﻿/*
* Created By Shemeer NS 
* This Code is created for demo purpose and uploaded in Codeproject
* My Other Articles in codeproject - http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=3175840
* */
using System;
using System.Collections.Generic;
using System.Web;

using System.Web.Configuration;
using EditableGridView.egClass;
using System.IO;
using System.Data;

namespace EditableGridView.egClass
{
    public class mainXML
    {
        static private string xmlConString
        {
            get { return HttpContext.Current.Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["xmlPath"].ToString()); }
        }
        public List<EmployeeInfo> getEmployeeList()
        {
            List<EmployeeInfo> eList = new List<EmployeeInfo>();
            EmployeeInfo objEmp = null;

            DataSet ds = new DataSet();
            ds.ReadXml(xmlConString);
            if (ds.Tables.Count != 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objEmp = new EmployeeInfo();
                    objEmp.ID = Convert.ToInt64(ds.Tables[0].Rows[i]["ID"]);
                    objEmp.EmployeeCode = Convert.ToString(ds.Tables[0].Rows[i]["EmployeeCode"]);
                    objEmp.EmployeeName = Convert.ToString(ds.Tables[0].Rows[i]["EmployeeName"]);
                    objEmp.DepartmentId = Convert.ToInt32(ds.Tables[0].Rows[i]["DepartmentId"]);
                    objEmp.DepartmentName = Convert.ToString(ds.Tables[0].Rows[i]["DepartmentName"]);
                    objEmp.EmployeeGroup = Convert.ToString(ds.Tables[0].Rows[i]["EmployeeGroup"]);
                    objEmp.Email = Convert.ToString(ds.Tables[0].Rows[i]["Email"]);
                    objEmp.isActive = Convert.ToBoolean(ds.Tables[0].Rows[i]["isActive"]);
                    eList.Add(objEmp);
                }
            }            
            return eList;
        }
        public List<Department> getDepartmentList()
        {
            List<Department> dList = new List<Department>();
            Department objDep = null;
            objDep = new Department();
            objDep.Id = 1;
            objDep.Name = "Sales";
            dList.Add(objDep);
            objDep = new Department();
            objDep.Id = 2;
            objDep.Name = "Marketing";
            dList.Add(objDep);
            objDep = new Department();
            objDep.Id = 3;
            objDep.Name = "IT";
            dList.Add(objDep);
            return dList;
        }
        public Boolean insertEmployeeInfo(EmployeeInfo eInfo)
        {            
            DataSet ds = new DataSet();
            ds.ReadXml(xmlConString);
            DataRow dr = ds.Tables[0].NewRow();
            dr[0] = eInfo.ID;
            dr[1] = eInfo.EmployeeCode;
            dr[2] = eInfo.EmployeeName;
            dr[3] = eInfo.DepartmentId;
            dr[4] = eInfo.DepartmentName;
            dr[5] = eInfo.EmployeeGroup;
            dr[6] = eInfo.Email;
            dr[7] = eInfo.isActive;
            ds.Tables[0].Rows.Add(dr);
            ds.AcceptChanges();
            ds.WriteXml(xmlConString);
            return true;
        }
        public Boolean updateEmployeeInfo(EmployeeInfo eInfo)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(xmlConString);
            if (ds.Tables.Count != 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt64(ds.Tables[0].Rows[i]["ID"]) == eInfo.ID)
                    {
                        ds.Tables[0].Rows[i]["ID"] = eInfo.ID;
                        ds.Tables[0].Rows[i]["EmployeeCode"] = eInfo.EmployeeCode;
                        ds.Tables[0].Rows[i]["EmployeeName"] = eInfo.EmployeeName;
                        ds.Tables[0].Rows[i]["DepartmentId"] = eInfo.DepartmentId;
                        ds.Tables[0].Rows[i]["DepartmentName"] = eInfo.DepartmentName;
                        ds.Tables[0].Rows[i]["EmployeeGroup"] = eInfo.EmployeeGroup;
                        ds.Tables[0].Rows[i]["Email"] = eInfo.Email;
                        ds.Tables[0].Rows[i]["isActive"] = eInfo.isActive;
                        ds.AcceptChanges();
                        ds.WriteXml(xmlConString);
                        break;
                    }
                }
            }       
            //XML Updated
            return true;
        }
        public Boolean deleteEmployeeInfo(long ID)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(xmlConString);
            if (ds.Tables.Count != 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt64(ds.Tables[0].Rows[i]["ID"]) == ID)
                    {
                        ds.Tables[0].Rows[i].Delete();
                        ds.AcceptChanges();
                        ds.WriteXml(xmlConString);
                        break;
                    }
                }
            }       
            //XML Element Deleted
            return true;
        }
    }
}