﻿/*
* Created By Shemeer NS 
* This Code is created for demo purpose and uploaded in Codeproject
* My Other Articles in codeproject - http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=3175840
* */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EditableGridView.egClass
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }        
    }

}