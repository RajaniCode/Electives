﻿/*
* Created By Shemeer NS 
* This Code is created for demo purpose and uploaded in Codeproject
* My Other Articles in codeproject - http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=3175840
* */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Web.Configuration;
using EditableGridView.egClass;
using System.Xml.Linq;
using System.IO;

namespace EditableGridView.egClass
{
    public class mainXML
    {
        static private string xmlConString
        {
            get { return HttpContext.Current.Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["xmlPath"].ToString()); }
        }
        public List<EmployeeInfo> getEmployeeList()
        {
            XDocument xmlContent = new XDocument();
            if (File.Exists(xmlConString))
            {
                xmlContent = XDocument.Load(xmlConString);
                var content = from data in xmlContent.Descendants("Employee")
                              select new EmployeeInfo
                              {
                                  ID = ((Int64)data.Element("ID")),
                                  EmployeeCode = ((string)data.Element("EmployeeCode")),
                                  EmployeeName = ((string)data.Element("EmployeeName")),
                                  DepartmentId = ((Int32)data.Element("DepartmentId")),
                                  DepartmentName = ((string)data.Element("DepartmentName")),
                                  EmployeeGroup = ((string)data.Element("EmployeeGroup")),
                                  Email = ((string)data.Element("Email")),
                                  isActive = ((bool)data.Element("isActive"))
                              };
                return content.ToList();
            }
            return null;
        }
        public List<Department> getDepartmentList()
        {
            List<Department> dList = new List<Department>();
            Department objDep = null;
            objDep = new Department();
            objDep.Id = 1;
            objDep.Name = "Sales";
            dList.Add(objDep);
            objDep = new Department();
            objDep.Id = 2;
            objDep.Name = "Marketing";
            dList.Add(objDep);
            objDep = new Department();
            objDep.Id = 3;
            objDep.Name = "IT";
            dList.Add(objDep);
            return dList;
        }
        public Boolean insertEmployeeInfo(EmployeeInfo eInfo)
        {
            if (!File.Exists(xmlConString))
            {
                XElement Profile = new XElement("Employee", new XElement("Employee",
                        new XElement("ID", 1),
                        new XElement("EmployeeCode", eInfo.EmployeeCode),
                        new XElement("EmployeeName", eInfo.EmployeeName),
                        new XElement("DepartmentId", eInfo.DepartmentId),
                        new XElement("DepartmentName", eInfo.DepartmentName),
                        new XElement("EmployeeGroup", eInfo.EmployeeGroup),
                        new XElement("Email", eInfo.Email),
                        new XElement("isActive", eInfo.isActive)));
                Profile.Save(xmlConString);
                //("XML File Created");
            }
            else
            {
                XElement doc = XElement.Load(xmlConString);
                XElement newProfile = new XElement("Employee",
                        new XElement("ID", doc.Elements("Employee").Max(m => int.Parse(m.Element("ID").Value) + 1)),
                        new XElement("EmployeeCode", eInfo.EmployeeCode),
                        new XElement("EmployeeName", eInfo.EmployeeName),
                        new XElement("DepartmentId", eInfo.DepartmentId),
                        new XElement("DepartmentName", eInfo.DepartmentName),
                        new XElement("EmployeeGroup", eInfo.EmployeeGroup),
                        new XElement("Email", eInfo.Email),
                        new XElement("isActive", eInfo.isActive));
                doc.Add(newProfile);
                doc.Save(xmlConString);
                //XML Appended
            }
            return true;
        }
        public Boolean updateEmployeeInfo(EmployeeInfo eInfo)
        {
            XDocument doc = XDocument.Load(xmlConString); 
            IEnumerable<XElement> oMemberList = doc.Element("Employees").Elements("Employee");
            var oMember = (from member in oMemberList
                           where
                           member.Element("ID").Value == eInfo.ID.ToString()
                           select member).SingleOrDefault();

                            oMember.SetElementValue("EmployeeCode", eInfo.EmployeeCode);
                            oMember.SetElementValue("EmployeeName", eInfo.EmployeeName);
                            oMember.SetElementValue("DepartmentId", eInfo.DepartmentId);
                            oMember.SetElementValue("DepartmentName", eInfo.DepartmentName);
                            oMember.SetElementValue("EmployeeGroup", eInfo.EmployeeGroup);
                            oMember.SetElementValue("Email", eInfo.Email);
                            oMember.SetElementValue("isActive", eInfo.isActive);
                            doc.Save(xmlConString);
            //XML Updated
            return true;
        }
        public Boolean deleteEmployeeInfo(long ID)
        {
            XDocument xml = new XDocument();
            xml = XDocument.Load(xmlConString);
            xml.Element("Employees").Elements("Employee").Where(x => x.Element("ID").Value.Trim() == ID.ToString()).Remove();
            xml.Save(xmlConString);
            //XML Element Deleted
            return true;
        }
    }
}