﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        gv.CssClass = "ui-widget-content";
        if (gv.Rows.Count > 0)
        {
            //To render header in accessible format
            gv.UseAccessibleHeader = true;

            //Add the <thead> element
            gv.HeaderRow.TableSection = TableRowSection.TableHeader;
            gv.HeaderRow.CssClass = "ui-widget-header";

            //Add the <tfoot> element
            gv.FooterRow.TableSection = TableRowSection.TableFooter;

            if (gv.TopPagerRow != null)
            {
                gv.TopPagerRow.TableSection = TableRowSection.TableHeader;
            }
            if (gv.BottomPagerRow != null)
            {
                gv.BottomPagerRow.TableSection = TableRowSection.TableFooter;
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}