This code is explained in the article over here 
www.dotnetcurry.com/ShowArticle.aspx?ID=658