﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace InventoryServiceLibrary
{
  [ServiceContract]
  public interface IInventoryService
  {
    [FaultContract(typeof(ConnectionFault))]
    [FaultContract(typeof(DataReaderFault))]
    [OperationContract]
    Int16 GetInStock(int productId);

    [OperationContract]
    Product GetProduct(int productId);

    [OperationContract]
    bool UpdateProduct(Product product);
  }

  [DataContract]
  public class Product
  {
    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public decimal UnitPrice { get; set; }

    [DataMember]
    public short UnitsInStock { get; set; }

    [DataMember]
    public short UnitsOnOrder { get; set; }
  }

  [DataContract]
  public class ConnectionFault
  {
    [DataMember]
    public string Issue { get; set; }

    [DataMember]
    public string Details { get; set; }
  }

  [DataContract]
  public class DataReaderFault
  {
    [DataMember]
    public string Issue { get; set; }

    [DataMember]
    public string Details { get; set; }
  }

}
