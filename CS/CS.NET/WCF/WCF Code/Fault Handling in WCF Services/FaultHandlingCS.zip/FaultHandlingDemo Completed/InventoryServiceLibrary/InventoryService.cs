﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace InventoryServiceLibrary
{
  public class InventoryService : IInventoryService
  {
    #region IInventoryService Members

    public short GetInStock(int productId)
    {
      short unitsInStock = 0;

      using (var cnn = new SqlConnection(
        Properties.Settings.Default.NorthwindConnectionString))
      {
        using (var cmd = new SqlCommand(
          "SELECT UnitsInStock FROM Products " +
          "WHERE ProductId = @productId", cnn))
        {
          cmd.Parameters.Add(new SqlParameter("@productId", productId));

          try
          {
            cnn.Open();
          }
          catch (Exception ex)
          {
            var connectionFault = new ConnectionFault();
            connectionFault.Issue = "Problem connecting to the database";
            connectionFault.Details = ex.Message;
            throw new FaultException<ConnectionFault>(connectionFault);
          }
          //catch
          //{
          //  throw new FaultException(
          //    "There was a problem connecting to the database.",
            //    new FaultCode("ConnectionFault"));
          //}
          using (SqlDataReader dataReader = cmd.ExecuteReader())
          {
            try
            {
              while (dataReader.Read())
              {
                unitsInStock = dataReader.GetInt16(1);
              }
            }
            catch (Exception ex)
            {
              var dataReaderFault = new DataReaderFault();
              dataReaderFault.Issue = "Problem reading the database";
              dataReaderFault.Details = ex.Message;
              throw new FaultException<DataReaderFault>(dataReaderFault);
            }
            //catch
            //{
            //  throw new FaultException(
            //    "There was a problem reading from the database.",
            //    new FaultCode("DataReaderFault"));
            //}
          }
        }
      }
      return unitsInStock;
    }

    public Product GetProduct(int productId)
    {
      var product = new Product();

      using (var cnn = new SqlConnection(
        Properties.Settings.Default.NorthwindConnectionString))
      {
        using (var cmd = new SqlCommand(
          "SELECT ProductName, UnitPrice, " +
          "UnitsInStock, UnitsOnOrder FROM Products " +
          "WHERE ProductId = @productId", cnn))
        {
          cmd.Parameters.Add(new SqlParameter(
            "@productId", productId));

          cnn.Open();
          using (SqlDataReader dataReader = cmd.ExecuteReader())
          {
            while (dataReader.Read())
            {
              product.ProductId = productId;
              product.ProductName = dataReader.GetString(0);
              product.UnitPrice = dataReader.GetDecimal(1);
              product.UnitsInStock = dataReader.GetInt16(2);
              product.UnitsOnOrder = dataReader.GetInt16(3);
            }
          }
        }
      }
      return product;
    }

    public bool UpdateProduct(Product product)
    {
      int rowsChanged = 0;

      using (var cnn = new SqlConnection(
        Properties.Settings.Default.NorthwindConnectionString))
      {
        using (var cmd = new SqlCommand(
          "UPDATE Products " +
          "SET UnitsInStock = @unitsInStock, " +
          "UnitsOnOrder = @unitsOnOrder " +
          "WHERE ProductId = @productId", cnn))
        {
          cmd.Parameters.Add(new SqlParameter(
            "@unitsInStock", product.UnitsInStock));
          cmd.Parameters.Add(new SqlParameter(
            "@unitsOnOrder", product.UnitsOnOrder));
          cmd.Parameters.Add(new SqlParameter(
            "@productId", product.ProductId));

          cnn.Open();
          rowsChanged = (int)cmd.ExecuteNonQuery();
        }
      }
      return (rowsChanged != 0);
    }

    #endregion
  }
}
