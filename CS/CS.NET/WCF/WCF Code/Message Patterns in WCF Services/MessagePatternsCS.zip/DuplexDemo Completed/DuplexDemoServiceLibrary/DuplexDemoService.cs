﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;

namespace DuplexDemoServiceLibrary
{
  public class DuplexDemoService : IDuplexDemoService
  {
    private StringWriter writeString = null;
    private string validStocks = "MSFT,GOOG,F,AAPL,ORCL,GE";

    public void BuyStock(string stock, int quantity)
    {
      IDuplexDemoServiceCallback callback =
        OperationContext.Current.GetCallbackChannel<
        IDuplexDemoServiceCallback>();

      // Create the MessagePatternDemos folder if necessary
      Directory.CreateDirectory("C:\\MessagePatternDemos");

      // Record the stock transaction 
      writeString = new StringWriter();
      string confirmation = string.Empty;
      if (ValidateStock(stock))
      {
        writeString.WriteLine(
          "{0} shares of {1} were purchased on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        confirmation=string.Format(
          "{0} shares of {1} were purchased", quantity, stock);
      }
      else
      {
        writeString.WriteLine(
          "Attempt to purchase {0} shares of {1} failed on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        confirmation=string.Format(
          "Attempt to purchase {0} shares of {1} failed", quantity, stock);
      }
      File.AppendAllText("C:\\MessagePatternDemos\\Transactions.txt",
        writeString.ToString());

      System.Threading.Thread.Sleep(new TimeSpan(0, 0, 5));
      callback.BuyStockCallBack(confirmation);
    }

    public void SellStock(string stock, int quantity)
    {
      IDuplexDemoServiceCallback callback =
        OperationContext.Current.GetCallbackChannel<
        IDuplexDemoServiceCallback>();

      // Create the MessagePatternDemos folder if necessary
      Directory.CreateDirectory("C:\\MessagePatternDemos");

      // Record the stock transaction 
      writeString = new StringWriter();
      string confirmation = string.Empty;
      if (ValidateStock(stock))
      {
        writeString.WriteLine(
          "{0} shares of {1} were sold on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        confirmation = string.Format(
          "{0} shares of {1} were sold", quantity, stock);
      }
      else
      {
        writeString.WriteLine(
          "Attempt to sell {0} shares of {1} failed on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        confirmation = string.Format(
          "Attempt to sell {0} shares of {1} failed", quantity, stock);
      }
      File.AppendAllText("C:\\MessagePatternDemos\\Transactions.txt",
        writeString.ToString());

      System.Threading.Thread.Sleep(new TimeSpan(0, 0, 5));
      callback.SellStockCallBack(confirmation);
    }

    private bool ValidateStock(string stock)
    {
      return (validStocks.IndexOf(stock) != -1);
    }
  }
}
