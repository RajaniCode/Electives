﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DuplexDemoServiceLibrary
{
  [ServiceContract(
    CallbackContract = typeof(IDuplexDemoServiceCallback))]
  public interface IDuplexDemoService
  {
    [OperationContract(IsOneWay = true)]
    void BuyStock(string stock, int quantity);

    [OperationContract(IsOneWay = true)]
    void SellStock(string stock, int quantity);
  }

  public interface IDuplexDemoServiceCallback
  {
    [OperationContract(IsOneWay = true)]
    void BuyStockCallBack(string message);

    [OperationContract(IsOneWay = true)]
    void SellStockCallBack(string message);
  }

}
