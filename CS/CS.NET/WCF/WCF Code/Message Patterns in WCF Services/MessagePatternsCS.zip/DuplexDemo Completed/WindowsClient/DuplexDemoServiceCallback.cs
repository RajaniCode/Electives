﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsClient
{
  class DuplexDemoServiceCallback: DuplexDemoService.IDuplexDemoServiceCallback
  {
    #region IDuplexDemoServiceCallback Members

    public void BuyStockCallBack(string message)
    {
      System.Windows.Forms.MessageBox.Show(message);
    }

    public void SellStockCallBack(string message)
    {
      System.Windows.Forms.MessageBox.Show(message);
    }

    #endregion
  }
}
