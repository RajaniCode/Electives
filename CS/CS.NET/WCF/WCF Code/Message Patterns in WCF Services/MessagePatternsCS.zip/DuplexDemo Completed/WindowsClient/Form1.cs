﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WindowsClient.DuplexDemoService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private DuplexDemoServiceClient proxy = null;

    private void Form1_Load(object sender, EventArgs e)
    {
      var context = new InstanceContext(
        new DuplexDemoServiceCallback());
      proxy = new DuplexDemoServiceClient(context);
    }

    private void buyButton_Click(object sender, EventArgs e)
    {
      proxy.BuyStock(stockTextBox.Text, 
        Convert.ToInt32(sharesTextBox.Text));
      stockTextBox.Clear();
      sharesTextBox.Clear();
    }

    private void sellButton_Click(object sender, EventArgs e)
    {
      proxy.SellStock(stockTextBox.Text,
        Convert.ToInt32(sharesTextBox.Text));
      stockTextBox.Clear();
      sharesTextBox.Clear();
    }

  }
}
