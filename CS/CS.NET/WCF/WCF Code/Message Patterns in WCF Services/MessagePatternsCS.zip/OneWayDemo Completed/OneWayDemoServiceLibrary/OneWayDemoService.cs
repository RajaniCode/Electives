﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;

namespace OneWayDemoServiceLibrary
{
  public class OneWayDemoService : IOneWayDemoService
  {
    private StringWriter writeString = null;
    private string validStocks = "MSFT,GOOG,F,AAPL,ORCL,GE";

    public void BuyStock(string stock, int quantity)
    {
      // Create the MessagePatternDemos folder if necessary
      Directory.CreateDirectory("C:\\MessagePatternDemos");

      // Record the stock transaction 
      writeString = new StringWriter();
      if (ValidateStock(stock))
      {
        writeString.WriteLine(
          "{0} shares of {1} were purchased on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
      }
      else
      {
        writeString.WriteLine(
          "Attempt to purchase {0} shares of {1} failed on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
      }
      File.AppendAllText("C:\\MessagePatternDemos\\Transactions.txt",
        writeString.ToString());
    }

    public void SellStock(string stock, int quantity)
    {
      // Create the MessagePatternDemos folder if necessary
      Directory.CreateDirectory("C:\\MessagePatternDemos");

      // Record the stock transaction 
      writeString = new StringWriter();
      if (ValidateStock(stock))
      {
        writeString.WriteLine(
          "{0} shares of {1} were sold on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        File.AppendAllText("C:\\MessagePatternDemos\\Transactions.txt",
          writeString.ToString());
      }
      else
      {
        writeString.WriteLine(
          "Attempt to sell {0} shares of {1} failed on {2} at {3}",
          quantity, stock, DateTime.Today.ToShortDateString(),
          DateTime.Now.ToShortTimeString());
        File.AppendAllText("C:\\MessagePatternDemos\\Transactions.txt",
          writeString.ToString());
        throw new FaultException(string.Format(
          "{0} is an invalid stock symbol", stock));
      }
    }

    private bool ValidateStock(string stock)
    {
      return (validStocks.IndexOf(stock) != -1);
    }
  }
}
