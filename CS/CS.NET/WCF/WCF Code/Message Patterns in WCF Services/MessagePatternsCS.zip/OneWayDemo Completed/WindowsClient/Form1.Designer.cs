﻿namespace WindowsClient
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.buyAndSellStocksButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // buyAndSellStocksButton
      // 
      this.buyAndSellStocksButton.Location = new System.Drawing.Point(79, 88);
      this.buyAndSellStocksButton.Name = "buyAndSellStocksButton";
      this.buyAndSellStocksButton.Size = new System.Drawing.Size(150, 39);
      this.buyAndSellStocksButton.TabIndex = 15;
      this.buyAndSellStocksButton.Text = "Buy and sell stocks";
      this.buyAndSellStocksButton.UseVisualStyleBackColor = true;
      this.buyAndSellStocksButton.Click += new System.EventHandler(this.buyAndSellStocksButton_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(309, 215);
      this.Controls.Add(this.buyAndSellStocksButton);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "One-Way Message Pattern Demo";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);

    }

    #endregion

    internal System.Windows.Forms.Button buyAndSellStocksButton;
  }
}

