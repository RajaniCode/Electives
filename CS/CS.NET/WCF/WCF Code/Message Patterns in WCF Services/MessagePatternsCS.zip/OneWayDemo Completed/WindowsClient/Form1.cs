﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WindowsClient.OneWayDemoService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private OneWayDemoServiceClient proxy = null;

    private void Form1_Load(object sender, EventArgs e)
    {
      proxy = new OneWayDemoServiceClient("WSHttpBinding_IOneWayDemoService");
    }

    private void buyAndSellStocksButton_Click(object sender, EventArgs e)
    {
      proxy.BuyStock("MSFT", 100);
      proxy.BuyStock("GOOG", 50);
      proxy.BuyStock("FMC", 500);

      proxy.SellStock("AAPL", 100);
      proxy.SellStock("ORCL", 300);
      proxy.SellStock("GMC", 75);

      MessageBox.Show("Finished");
    }

  }
}
