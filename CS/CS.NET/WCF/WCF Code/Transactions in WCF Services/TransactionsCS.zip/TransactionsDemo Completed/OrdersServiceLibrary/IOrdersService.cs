﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace OrdersServiceLibrary
{
  [ServiceContract(SessionMode=SessionMode.Required)]
  public interface IOrdersService
  {
    [OperationContract]
    [TransactionFlow(TransactionFlowOption.NotAllowed)]
    List<Customer> GetCustomers();

    [OperationContract]
    [TransactionFlow(TransactionFlowOption.NotAllowed)]
    List<Product> GetProducts();

    [OperationContract]
    [TransactionFlow(TransactionFlowOption.Mandatory)]
    string PlaceOrder(Order order);

    [OperationContract]
    [TransactionFlow(TransactionFlowOption.Mandatory)]
    string AdjustInventory(int productId, int quantity);

    [OperationContract]
    [TransactionFlow(TransactionFlowOption.Mandatory)]
    string AdjustBalance(int customerId, decimal amount);
  }

  [DataContract]
  public class Customer
  {
    [DataMember]
    public int CustomerId { get; set; }

    [DataMember]
    public string CompanyName { get; set; }

    [DataMember]
    public decimal Balance { get; set; }
  }

  [DataContract]
  public class Product
  {
    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public decimal Price { get; set; }

    [DataMember]
    public int OnHand { get; set; }
  }

  [DataContract]
  public class Order
  {
    [DataMember]
    public int CustomerId { get; set; }

    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public decimal Price { get; set; }

    [DataMember]
    public int Quantity { get; set; }

    [DataMember]
    public decimal Amount { get; set; }
  }
}
