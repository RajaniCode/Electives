﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace OrdersServiceLibrary
{
  [ServiceContract]
  public interface IOrdersService
  {
    [OperationContract]
    List<Customer> GetCustomers();

    [OperationContract]
    List<Product> GetProducts();

    [OperationContract]
    string PlaceOrder(Order order);

    [OperationContract]
    string AdjustInventory(int productId, int quantity);

    [OperationContract]
    string AdjustBalance(int customerId, decimal amount);
  }

  [DataContract]
  public class Customer
  {
    [DataMember]
    public int CustomerId { get; set; }

    [DataMember]
    public string CompanyName { get; set; }

    [DataMember]
    public decimal Balance { get; set; }
  }

  [DataContract]
  public class Product
  {
    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public decimal Price { get; set; }

    [DataMember]
    public int OnHand { get; set; }
  }

  [DataContract]
  public class Order
  {
    [DataMember]
    public int CustomerId { get; set; }

    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public decimal Price { get; set; }

    [DataMember]
    public int Quantity { get; set; }

    [DataMember]
    public decimal Amount { get; set; }
  }
}
