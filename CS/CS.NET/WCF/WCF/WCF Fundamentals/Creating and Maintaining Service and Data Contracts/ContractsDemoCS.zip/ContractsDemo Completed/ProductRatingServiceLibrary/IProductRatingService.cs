﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ProductRatingServiceLibrary
{
  [ServiceContract(Namespace = "http://www.mcwtech.com/wcf/2009/05", 
    Name="Ratings")]
  public interface IProductRatingService
  {
    [OperationContract(Name="GetAllRatings")]
    List<ProductRating> GetRatings();

    [OperationContract(Name="GetLastRating")]
    ProductRating GetRating();

    [OperationContract(Name="AddNewRating")]
    void AddRating(ProductRating productRating);

    [OperationContract(Name="GetAverageScore")]
    double CalcAverageScore();
  }

  [DataContract(
    Namespace = "http://www.mcwtech.com/wcf/schemas/2009/05", Name="Rating")]
  public class ProductRating
  {
    [DataMember(Name="Submitted", Order=2)]
    public DateTime DateSubmitted { get; set; }

    [DataMember(Name="Product", Order=1)]
    public string ProductName { get; set; }

    [DataMember(Name="Score", Order=3)]
    public int AverageScore { get; set; }

    [DataMember(Name="Details", Order=4)]
    public string Notes { get; set; }

    [DataMember(Name="Author", IsRequired=true, Order=5)]
    public string SubmittedBy { get; set; }
  }
}
