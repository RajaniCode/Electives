﻿namespace WindowsClient
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.ratingsDataGridView = new System.Windows.Forms.DataGridView();
      this.getRatingbutton = new System.Windows.Forms.Button();
      this.clearButton = new System.Windows.Forms.Button();
      this.saveRatingButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.dateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
      this.productTextBox = new System.Windows.Forms.TextBox();
      this.scoreTextBox = new System.Windows.Forms.TextBox();
      this.notesTextBox = new System.Windows.Forms.TextBox();
      this.getAverageButton = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.ratingsDataGridView)).BeginInit();
      this.SuspendLayout();
      // 
      // ratingsDataGridView
      // 
      this.ratingsDataGridView.AllowUserToAddRows = false;
      this.ratingsDataGridView.AllowUserToDeleteRows = false;
      this.ratingsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.ratingsDataGridView.Location = new System.Drawing.Point(30, 28);
      this.ratingsDataGridView.Name = "ratingsDataGridView";
      this.ratingsDataGridView.ReadOnly = true;
      this.ratingsDataGridView.RowHeadersVisible = false;
      this.ratingsDataGridView.Size = new System.Drawing.Size(675, 230);
      this.ratingsDataGridView.TabIndex = 1;
      // 
      // getRatingbutton
      // 
      this.getRatingbutton.Location = new System.Drawing.Point(30, 305);
      this.getRatingbutton.Name = "getRatingbutton";
      this.getRatingbutton.Size = new System.Drawing.Size(125, 39);
      this.getRatingbutton.TabIndex = 2;
      this.getRatingbutton.Text = "Get rating";
      this.getRatingbutton.UseVisualStyleBackColor = true;
      this.getRatingbutton.Click += new System.EventHandler(this.getRatingbutton_Click);
      // 
      // clearButton
      // 
      this.clearButton.Location = new System.Drawing.Point(30, 350);
      this.clearButton.Name = "clearButton";
      this.clearButton.Size = new System.Drawing.Size(125, 39);
      this.clearButton.TabIndex = 3;
      this.clearButton.Text = "Clear";
      this.clearButton.UseVisualStyleBackColor = true;
      this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
      // 
      // saveRatingButton
      // 
      this.saveRatingButton.Location = new System.Drawing.Point(30, 395);
      this.saveRatingButton.Name = "saveRatingButton";
      this.saveRatingButton.Size = new System.Drawing.Size(125, 39);
      this.saveRatingButton.TabIndex = 4;
      this.saveRatingButton.Text = "Save rating";
      this.saveRatingButton.UseVisualStyleBackColor = true;
      this.saveRatingButton.Click += new System.EventHandler(this.saveRatingButton_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(194, 305);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(42, 17);
      this.label1.TabIndex = 5;
      this.label1.Text = "Date:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(194, 343);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(61, 17);
      this.label2.TabIndex = 6;
      this.label2.Text = "Product:";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(194, 381);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(49, 17);
      this.label3.TabIndex = 7;
      this.label3.Text = "Score:";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(194, 419);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(49, 17);
      this.label4.TabIndex = 8;
      this.label4.Text = "Notes:";
      // 
      // dateMaskedTextBox
      // 
      this.dateMaskedTextBox.Location = new System.Drawing.Point(276, 302);
      this.dateMaskedTextBox.Mask = "00/00/0000";
      this.dateMaskedTextBox.Name = "dateMaskedTextBox";
      this.dateMaskedTextBox.Size = new System.Drawing.Size(100, 23);
      this.dateMaskedTextBox.TabIndex = 9;
      this.dateMaskedTextBox.ValidatingType = typeof(System.DateTime);
      // 
      // productTextBox
      // 
      this.productTextBox.Location = new System.Drawing.Point(276, 340);
      this.productTextBox.Name = "productTextBox";
      this.productTextBox.Size = new System.Drawing.Size(429, 23);
      this.productTextBox.TabIndex = 10;
      // 
      // scoreTextBox
      // 
      this.scoreTextBox.Location = new System.Drawing.Point(276, 378);
      this.scoreTextBox.Name = "scoreTextBox";
      this.scoreTextBox.Size = new System.Drawing.Size(50, 23);
      this.scoreTextBox.TabIndex = 11;
      // 
      // notesTextBox
      // 
      this.notesTextBox.Location = new System.Drawing.Point(276, 416);
      this.notesTextBox.Name = "notesTextBox";
      this.notesTextBox.Size = new System.Drawing.Size(429, 23);
      this.notesTextBox.TabIndex = 12;
      // 
      // getAverageButton
      // 
      this.getAverageButton.Location = new System.Drawing.Point(580, 283);
      this.getAverageButton.Name = "getAverageButton";
      this.getAverageButton.Size = new System.Drawing.Size(125, 39);
      this.getAverageButton.TabIndex = 13;
      this.getAverageButton.Text = "Get average";
      this.getAverageButton.UseVisualStyleBackColor = true;
      this.getAverageButton.Click += new System.EventHandler(this.getAverageButton_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(734, 465);
      this.Controls.Add(this.getAverageButton);
      this.Controls.Add(this.notesTextBox);
      this.Controls.Add(this.scoreTextBox);
      this.Controls.Add(this.productTextBox);
      this.Controls.Add(this.dateMaskedTextBox);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.saveRatingButton);
      this.Controls.Add(this.clearButton);
      this.Controls.Add(this.getRatingbutton);
      this.Controls.Add(this.ratingsDataGridView);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Product Ratings";
      this.Load += new System.EventHandler(this.Form1_Load);
      ((System.ComponentModel.ISupportInitialize)(this.ratingsDataGridView)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView ratingsDataGridView;
    private System.Windows.Forms.Button getRatingbutton;
    private System.Windows.Forms.Button clearButton;
    private System.Windows.Forms.Button saveRatingButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.MaskedTextBox dateMaskedTextBox;
    private System.Windows.Forms.TextBox productTextBox;
    private System.Windows.Forms.TextBox scoreTextBox;
    private System.Windows.Forms.TextBox notesTextBox;
    private System.Windows.Forms.Button getAverageButton;
  }
}

