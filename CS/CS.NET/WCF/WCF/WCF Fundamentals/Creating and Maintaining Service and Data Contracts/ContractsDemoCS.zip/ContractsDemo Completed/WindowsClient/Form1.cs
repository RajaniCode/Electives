﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsClient.ProductRatingService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    private RatingsClient proxy = null;
    private Rating productRating = null;
    private List<Rating> productRatings = null;

    private void Form1_Load(object sender, EventArgs e)
    {
      proxy = new RatingsClient("WSHttpBinding_Ratings");

      productRatings = proxy.GetAllRatings();
      ratingsDataGridView.DataSource = productRatings;
      ratingsDataGridView.AutoResizeColumns();
    }

    private void getRatingbutton_Click(object sender, EventArgs e)
    {
      productRating = proxy.GetLastRating();
      dateMaskedTextBox.Text = 
        productRating.Submitted.ToString("MM/dd/yyyy");
      productTextBox.Text = productRating.Product;
      scoreTextBox.Text = productRating.Score.ToString();
      notesTextBox.Text = productRating.Details;
    }

    private void clearButton_Click(object sender, EventArgs e)
    {
      ClearTextBoxes();
    }

    private void saveRatingButton_Click(object sender, EventArgs e)
    {
      productRating = new Rating();
      productRating.Submitted = 
        Convert.ToDateTime(dateMaskedTextBox.Text);
      productRating.Product = productTextBox.Text;
      productRating.Score = Convert.ToInt32(scoreTextBox.Text);
      productRating.Details = notesTextBox.Text;
      productRating.Author = "Robert";

      proxy.AddNewRating(productRating);
      ClearTextBoxes();

      productRatings = proxy.GetAllRatings();
      ratingsDataGridView.DataSource = productRatings;
      ratingsDataGridView.AutoResizeColumns();
    }

    private void getAverageButton_Click(object sender, EventArgs e)
    {
      MessageBox.Show(string.Format(
        "The average score is {0:F1}", proxy.GetAverageScore()));
    }

    private void ClearTextBoxes()
    {
      dateMaskedTextBox.Clear();
      productTextBox.Clear();
      scoreTextBox.Clear();
      notesTextBox.Clear();
    }

  }
}
