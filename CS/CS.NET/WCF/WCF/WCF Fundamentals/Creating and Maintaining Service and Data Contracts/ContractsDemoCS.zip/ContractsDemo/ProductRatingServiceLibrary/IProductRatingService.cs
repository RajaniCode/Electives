﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ProductRatingServiceLibrary
{
  [ServiceContract]
  public interface IProductRatingService
  {
    [OperationContract]
    List<ProductRating> GetRatings();

    [OperationContract]
    ProductRating GetRating();

    [OperationContract]
    void AddRating(ProductRating productRating);
  }

  [DataContract]
  public class ProductRating
  {
    [DataMember]
    public DateTime DateSubmitted { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public int AverageScore { get; set; }

    [DataMember]
    public string Notes { get; set; }
  }
}
