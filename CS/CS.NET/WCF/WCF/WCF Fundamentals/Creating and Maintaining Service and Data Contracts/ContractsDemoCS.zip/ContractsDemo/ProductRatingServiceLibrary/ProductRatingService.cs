﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ProductRatingServiceLibrary
{
  public class ProductRatingService : IProductRatingService
  {
    private List<ProductRating> productRatings = null;

    public List<ProductRating> GetRatings()
    {
      if (productRatings == null)
      {
        InitializeRatings();
      }
      return productRatings;
    }

    public ProductRating GetRating()
    {
      var productRating = new ProductRating();
      productRating = productRatings[productRatings.Count-1];
      return productRating;
    }

    public void AddRating(ProductRating productRating)
    {
      productRatings.Add(productRating);
    }

    private void InitializeRatings()
    {
      productRatings = new List<ProductRating>();
      var productRating = new ProductRating()
      {
        DateSubmitted=new DateTime(2009, 2, 1), 
        ProductName="Aniseed Syrup", AverageScore=7,
        Notes="Lots of favorable comments"
      };
      productRatings.Add(productRating);
      
      productRating = new ProductRating()
      {
        DateSubmitted=new DateTime(2009, 3, 1),
        ProductName = "Sir Rodney's Scones", AverageScore = 9,
        Notes="Everybody's favorite"
      };
      productRatings.Add(productRating);
      
      productRating = new ProductRating()
      {
        DateSubmitted=new DateTime(2009, 4, 1),
        ProductName = "Mascarpone Fabioli", AverageScore = 3,
        Notes="Didn't find anyone who really likes this"
      };
      productRatings.Add(productRating);
    }

  }
}
