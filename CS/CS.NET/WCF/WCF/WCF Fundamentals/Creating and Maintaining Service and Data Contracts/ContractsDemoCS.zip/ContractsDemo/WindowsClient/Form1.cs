﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsClient.ProductRatingService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    private ProductRatingServiceClient proxy = null;
    private ProductRating productRating = null;
    private List<ProductRating> productRatings = null;

    private void Form1_Load(object sender, EventArgs e)
    {
      proxy = new ProductRatingServiceClient(
        "WSHttpBinding_IProductRatingService");

      productRatings = proxy.GetRatings();
      ratingsDataGridView.DataSource = productRatings;
      ratingsDataGridView.AutoResizeColumns();
    }

    private void getRatingbutton_Click(object sender, EventArgs e)
    {
      productRating = proxy.GetRating();
      dateMaskedTextBox.Text = productRating.DateSubmitted.ToString("MM/dd/yyyy");
      productTextBox.Text = productRating.ProductName;
      scoreTextBox.Text = productRating.AverageScore.ToString();
      notesTextBox.Text = productRating.Notes;
    }

    private void clearButton_Click(object sender, EventArgs e)
    {
      ClearTextBoxes();
    }

    private void saveRatingButton_Click(object sender, EventArgs e)
    {
      productRating = new ProductRating();
      productRating.DateSubmitted = Convert.ToDateTime(dateMaskedTextBox.Text);
      productRating.ProductName = productTextBox.Text;
      productRating.AverageScore = Convert.ToInt32(scoreTextBox.Text);
      productRating.Notes = notesTextBox.Text;

      proxy.AddRating(productRating);
      ClearTextBoxes();

      productRatings = proxy.GetRatings();
      ratingsDataGridView.DataSource = productRatings;
      ratingsDataGridView.AutoResizeColumns();
    }

    private void ClearTextBoxes()
    {
      dateMaskedTextBox.Clear();
      productTextBox.Clear();
      scoreTextBox.Clear();
      notesTextBox.Clear();
    }

  }
}
