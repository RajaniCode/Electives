﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace InventoryServiceLibrary
{
  // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in App.config.
  [ServiceContract]
  public interface IInventoryService
  {
    [OperationContract]
    Int16 GetInStock(int productId);

    [OperationContract]
    Product GetProduct(int productId);

    [OperationContract]
    bool UpdateProduct(Product product);
  }

  // Use a data contract as illustrated in the sample below to add composite types to service operations
  [DataContract]
  public class Product
  {
    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public decimal UnitPrice { get; set; }

    [DataMember]
    public short UnitsInStock { get; set; }

    [DataMember]
    public short UnitsOnOrder { get; set; }
  }
}
