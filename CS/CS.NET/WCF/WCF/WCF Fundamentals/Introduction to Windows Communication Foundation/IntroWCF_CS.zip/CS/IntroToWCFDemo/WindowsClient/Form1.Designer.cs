﻿namespace WindowsClient
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.productIdTextBox = new System.Windows.Forms.TextBox();
      this.getInStockButton = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.productNameLabel = new System.Windows.Forms.Label();
      this.unitPricelabel = new System.Windows.Forms.Label();
      this.inStockTextBox = new System.Windows.Forms.TextBox();
      this.onOrderTextBox = new System.Windows.Forms.TextBox();
      this.inStockValueLabel = new System.Windows.Forms.Label();
      this.onOrderValueLabel = new System.Windows.Forms.Label();
      this.updateProductButton = new System.Windows.Forms.Button();
      this.getProductButton = new System.Windows.Forms.Button();
      this.inStockLabel = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // productIdTextBox
      // 
      this.productIdTextBox.Location = new System.Drawing.Point(90, 37);
      this.productIdTextBox.Margin = new System.Windows.Forms.Padding(4);
      this.productIdTextBox.Name = "productIdTextBox";
      this.productIdTextBox.Size = new System.Drawing.Size(50, 23);
      this.productIdTextBox.TabIndex = 0;
      // 
      // getInStockButton
      // 
      this.getInStockButton.Location = new System.Drawing.Point(156, 29);
      this.getInStockButton.Margin = new System.Windows.Forms.Padding(4);
      this.getInStockButton.Name = "getInStockButton";
      this.getInStockButton.Size = new System.Drawing.Size(125, 39);
      this.getInStockButton.TabIndex = 1;
      this.getInStockButton.Text = "Get in stock";
      this.getInStockButton.UseVisualStyleBackColor = true;
      this.getInStockButton.Click += new System.EventHandler(this.findButton_Click);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(156, 203);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(73, 17);
      this.label2.TabIndex = 3;
      this.label2.Text = "Unit Price:";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(156, 165);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(102, 17);
      this.label1.TabIndex = 5;
      this.label1.Text = "Product Name:";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(156, 262);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(62, 17);
      this.label3.TabIndex = 6;
      this.label3.Text = "In Stock:";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(156, 300);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(72, 17);
      this.label4.TabIndex = 7;
      this.label4.Text = "On Order:";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(354, 262);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(48, 17);
      this.label5.TabIndex = 8;
      this.label5.Text = "Value:";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(354, 300);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(48, 17);
      this.label6.TabIndex = 9;
      this.label6.Text = "Value:";
      // 
      // productNameLabel
      // 
      this.productNameLabel.AutoSize = true;
      this.productNameLabel.Location = new System.Drawing.Point(264, 165);
      this.productNameLabel.Name = "productNameLabel";
      this.productNameLabel.Size = new System.Drawing.Size(38, 17);
      this.productNameLabel.TabIndex = 10;
      this.productNameLabel.Text = "label";
      // 
      // unitPricelabel
      // 
      this.unitPricelabel.AutoSize = true;
      this.unitPricelabel.Location = new System.Drawing.Point(264, 203);
      this.unitPricelabel.Name = "unitPricelabel";
      this.unitPricelabel.Size = new System.Drawing.Size(38, 17);
      this.unitPricelabel.TabIndex = 11;
      this.unitPricelabel.Text = "label";
      // 
      // inStockTextBox
      // 
      this.inStockTextBox.Location = new System.Drawing.Point(264, 259);
      this.inStockTextBox.Name = "inStockTextBox";
      this.inStockTextBox.Size = new System.Drawing.Size(50, 23);
      this.inStockTextBox.TabIndex = 12;
      // 
      // onOrderTextBox
      // 
      this.onOrderTextBox.Location = new System.Drawing.Point(264, 297);
      this.onOrderTextBox.Name = "onOrderTextBox";
      this.onOrderTextBox.Size = new System.Drawing.Size(50, 23);
      this.onOrderTextBox.TabIndex = 13;
      // 
      // inStockValueLabel
      // 
      this.inStockValueLabel.AutoSize = true;
      this.inStockValueLabel.Location = new System.Drawing.Point(424, 262);
      this.inStockValueLabel.Name = "inStockValueLabel";
      this.inStockValueLabel.Size = new System.Drawing.Size(38, 17);
      this.inStockValueLabel.TabIndex = 14;
      this.inStockValueLabel.Text = "label";
      // 
      // onOrderValueLabel
      // 
      this.onOrderValueLabel.AutoSize = true;
      this.onOrderValueLabel.Location = new System.Drawing.Point(424, 300);
      this.onOrderValueLabel.Name = "onOrderValueLabel";
      this.onOrderValueLabel.Size = new System.Drawing.Size(38, 17);
      this.onOrderValueLabel.TabIndex = 15;
      this.onOrderValueLabel.Text = "label";
      // 
      // updateProductButton
      // 
      this.updateProductButton.Location = new System.Drawing.Point(302, 95);
      this.updateProductButton.Name = "updateProductButton";
      this.updateProductButton.Size = new System.Drawing.Size(125, 39);
      this.updateProductButton.TabIndex = 16;
      this.updateProductButton.Text = "Update product";
      this.updateProductButton.UseVisualStyleBackColor = true;
      this.updateProductButton.Click += new System.EventHandler(this.updateProductButton_Click);
      // 
      // getProductButton
      // 
      this.getProductButton.Location = new System.Drawing.Point(156, 95);
      this.getProductButton.Margin = new System.Windows.Forms.Padding(4);
      this.getProductButton.Name = "getProductButton";
      this.getProductButton.Size = new System.Drawing.Size(125, 39);
      this.getProductButton.TabIndex = 17;
      this.getProductButton.Text = "Get product";
      this.getProductButton.UseVisualStyleBackColor = true;
      this.getProductButton.Click += new System.EventHandler(this.getProductButton_Click);
      // 
      // inStockLabel
      // 
      this.inStockLabel.AutoSize = true;
      this.inStockLabel.Location = new System.Drawing.Point(299, 38);
      this.inStockLabel.Name = "inStockLabel";
      this.inStockLabel.Size = new System.Drawing.Size(38, 17);
      this.inStockLabel.TabIndex = 18;
      this.inStockLabel.Text = "label";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(22, 38);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(61, 17);
      this.label7.TabIndex = 19;
      this.label7.Text = "Product:";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(509, 365);
      this.Controls.Add(this.label7);
      this.Controls.Add(this.inStockLabel);
      this.Controls.Add(this.getProductButton);
      this.Controls.Add(this.updateProductButton);
      this.Controls.Add(this.onOrderValueLabel);
      this.Controls.Add(this.inStockValueLabel);
      this.Controls.Add(this.onOrderTextBox);
      this.Controls.Add(this.inStockTextBox);
      this.Controls.Add(this.unitPricelabel);
      this.Controls.Add(this.productNameLabel);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.getInStockButton);
      this.Controls.Add(this.productIdTextBox);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Manage Inventory";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox productIdTextBox;
    private System.Windows.Forms.Button getInStockButton;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label productNameLabel;
    private System.Windows.Forms.Label unitPricelabel;
    private System.Windows.Forms.TextBox inStockTextBox;
    private System.Windows.Forms.TextBox onOrderTextBox;
    private System.Windows.Forms.Label inStockValueLabel;
    private System.Windows.Forms.Label onOrderValueLabel;
    private System.Windows.Forms.Button updateProductButton;
    private System.Windows.Forms.Button getProductButton;
    private System.Windows.Forms.Label inStockLabel;
    private System.Windows.Forms.Label label7;
  }
}

