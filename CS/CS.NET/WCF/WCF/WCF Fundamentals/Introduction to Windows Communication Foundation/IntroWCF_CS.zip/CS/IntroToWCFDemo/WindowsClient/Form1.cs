﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WindowsClient.InventoryService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    private Product product = null;
    private InventoryServiceClient proxy = null;
    private decimal inStockValue = 0M;
    private decimal onOrderValue = 0M;

    private void Form1_Load(object sender, EventArgs e)
    {
      proxy = new InventoryServiceClient(
        "WSHttpBinding_IInventoryService");
    }

    private void findButton_Click(object sender, EventArgs e)
    {
      inStockLabel.Text = string.Format("{0} units are in stock", 
        proxy.GetInStock(Convert.ToInt32(productIdTextBox.Text)));
    }

    private void getProductButton_Click(object sender, EventArgs e)
    {
      product = new Product();
      product = proxy.GetProduct(
        Convert.ToInt32(productIdTextBox.Text));

      productNameLabel.Text = product.ProductName;
      unitPricelabel.Text = product.UnitPrice.ToString("C");
      inStockTextBox.Text = product.UnitsInStock.ToString();
      inStockValue=product.UnitPrice * 
        Convert.ToDecimal(product.UnitsInStock);
      inStockValueLabel.Text = inStockValue.ToString("C");
      onOrderTextBox.Text = product.UnitsOnOrder.ToString();
      onOrderValue=product.UnitPrice *
        Convert.ToDecimal(product.UnitsOnOrder);
      onOrderValueLabel.Text = onOrderValue.ToString("C");
    }

    private void updateProductButton_Click(object sender, EventArgs e)
    {
      product.UnitsInStock = Convert.ToInt16(inStockTextBox.Text);
      product.UnitsOnOrder = Convert.ToInt16(onOrderTextBox.Text);

      if (proxy.UpdateProduct(product))
      {
        MessageBox.Show("Your changes were saved");

        inStockValue = product.UnitPrice *
          Convert.ToDecimal(product.UnitsInStock);
        inStockValueLabel.Text = inStockValue.ToString("C");
        onOrderValue = product.UnitPrice *
          Convert.ToDecimal(product.UnitsOnOrder);
        onOrderValueLabel.Text = onOrderValue.ToString("C");
      }
      else
      {
        MessageBox.Show("Your changes were not saved");
      }
    }

  }
}
