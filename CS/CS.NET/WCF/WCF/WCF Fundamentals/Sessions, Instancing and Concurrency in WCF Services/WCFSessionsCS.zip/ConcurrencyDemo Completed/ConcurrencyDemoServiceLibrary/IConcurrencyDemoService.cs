﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ConcurrencyDemoServiceLibrary
{
  [ServiceContract]
  public interface IConcurrencyDemoService
  {
    [OperationContract(IsOneWay = true)]
    void BuyStock(string stock, int quantity);

    [OperationContract(IsOneWay = true)]
    void SellStock(string stock, int quantity);
  }

}
