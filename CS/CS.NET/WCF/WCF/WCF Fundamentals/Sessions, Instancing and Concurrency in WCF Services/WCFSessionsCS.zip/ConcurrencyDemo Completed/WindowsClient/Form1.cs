﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WindowsClient.ConcurrencyDemoServiceReference;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private int item = 1;
    private string product = String.Empty;
    private int inStock = 0;
    private ConcurrencyDemoServiceClient proxy = null;

    private void Form1_Load(object sender, EventArgs e)
    {
      proxy = new ConcurrencyDemoServiceClient("ConcurrencyDemoService_Tcp");
    }

    private void buyAndSellStocksButton_Click(object sender, EventArgs e)
    {
      proxy.BuyStock("MSFT", 100);
      proxy.BuyStock("GOOG", 50);
      proxy.BuyStock("F", 500);

      proxy.SellStock("AAPL", 100);
      proxy.SellStock("ORCL", 300);
      proxy.SellStock("GM", 75);
    }

  }
}
