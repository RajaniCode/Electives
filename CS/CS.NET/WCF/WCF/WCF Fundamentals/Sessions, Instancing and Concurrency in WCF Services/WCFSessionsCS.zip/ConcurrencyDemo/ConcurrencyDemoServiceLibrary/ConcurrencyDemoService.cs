﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ConcurrencyDemoServiceLibrary
{
  public class ConcurrencyDemoService : IConcurrencyDemoService
  {
    public void BuyStock(string stock, int quantity)
    {
      Console.WriteLine("Time {0:T}", DateTime.Now);
      System.Threading.Thread.Sleep(new TimeSpan(0, 0, 5));
      Console.WriteLine(String.Format(
        "{0} shares of {1} were bought", quantity, stock));
      Console.WriteLine("Time {0:T}\n", DateTime.Now);
    }

    public void SellStock(string stock, int quantity)
    {
      Console.WriteLine("Time {0:T}", DateTime.Now);
      System.Threading.Thread.Sleep(new TimeSpan(0, 0, 5));
      Console.WriteLine(String.Format(
        "{0} shares of {1} were sold", quantity, stock));
      Console.WriteLine("Time {0:T}\n", DateTime.Now);
    }
  }
}
