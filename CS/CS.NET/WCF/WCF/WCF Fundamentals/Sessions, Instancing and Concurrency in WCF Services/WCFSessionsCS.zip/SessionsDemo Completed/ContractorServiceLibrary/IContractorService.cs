﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ContractorServiceLibrary
{
  [ServiceContract(SessionMode=SessionMode.Required)]
  public interface IContractorService
  {
    [OperationContract(IsInitiating=true, IsTerminating=true)]
    List<Project> GetProjects();

    [OperationContract(IsInitiating=false, IsTerminating=false)]
    void RequestProject(Project project);

    [OperationContract(IsInitiating=false, IsTerminating=true)]
    List<Project> GetRequestedProjects();

    [OperationContract(IsInitiating=true, IsTerminating=false)]
    void StartOver();
  }

  [DataContract]
  public class Project
  {
    [DataMember]
    public string ProjectName { get; set; }

    [DataMember]
    public decimal MinimumCost { get; set; }
  }

}
