﻿namespace WindowsClient
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.Label2 = new System.Windows.Forms.Label();
      this.showRequestsButton = new System.Windows.Forms.Button();
      this.addRequestButton = new System.Windows.Forms.Button();
      this.cartLabel = new System.Windows.Forms.Label();
      this.requestedProjectsListBox = new System.Windows.Forms.ListBox();
      this.projectsListBox = new System.Windows.Forms.ListBox();
      this.getProjectsButton = new System.Windows.Forms.Button();
      this.startOverButton = new System.Windows.Forms.Button();
      this.GroupBox1 = new System.Windows.Forms.GroupBox();
      this.basicHttpRadioButton = new System.Windows.Forms.RadioButton();
      this.wsHttpRadioButton = new System.Windows.Forms.RadioButton();
      this.tcpRadioButton = new System.Windows.Forms.RadioButton();
      this.GroupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // Label2
      // 
      this.Label2.AutoSize = true;
      this.Label2.Location = new System.Drawing.Point(27, 98);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(106, 17);
      this.Label2.TabIndex = 16;
      this.Label2.Text = "Select a project";
      // 
      // showRequestsButton
      // 
      this.showRequestsButton.Location = new System.Drawing.Point(406, 306);
      this.showRequestsButton.Name = "showRequestsButton";
      this.showRequestsButton.Size = new System.Drawing.Size(125, 39);
      this.showRequestsButton.TabIndex = 30;
      this.showRequestsButton.Text = "Show requests";
      this.showRequestsButton.UseVisualStyleBackColor = true;
      this.showRequestsButton.Click += new System.EventHandler(this.showRequestsButton_Click);
      // 
      // addRequestButton
      // 
      this.addRequestButton.Location = new System.Drawing.Point(406, 199);
      this.addRequestButton.Name = "addRequestButton";
      this.addRequestButton.Size = new System.Drawing.Size(125, 39);
      this.addRequestButton.TabIndex = 26;
      this.addRequestButton.Text = "Add request";
      this.addRequestButton.UseVisualStyleBackColor = true;
      this.addRequestButton.Click += new System.EventHandler(this.addRequestButton_Click);
      // 
      // cartLabel
      // 
      this.cartLabel.AutoSize = true;
      this.cartLabel.Location = new System.Drawing.Point(27, 280);
      this.cartLabel.Name = "cartLabel";
      this.cartLabel.Size = new System.Drawing.Size(101, 17);
      this.cartLabel.TabIndex = 28;
      this.cartLabel.Text = "You requested";
      // 
      // requestedProjectsListBox
      // 
      this.requestedProjectsListBox.FormattingEnabled = true;
      this.requestedProjectsListBox.ItemHeight = 16;
      this.requestedProjectsListBox.Location = new System.Drawing.Point(30, 306);
      this.requestedProjectsListBox.Name = "requestedProjectsListBox";
      this.requestedProjectsListBox.Size = new System.Drawing.Size(334, 116);
      this.requestedProjectsListBox.TabIndex = 27;
      // 
      // projectsListBox
      // 
      this.projectsListBox.FormattingEnabled = true;
      this.projectsListBox.ItemHeight = 16;
      this.projectsListBox.Location = new System.Drawing.Point(30, 122);
      this.projectsListBox.Name = "projectsListBox";
      this.projectsListBox.Size = new System.Drawing.Size(334, 116);
      this.projectsListBox.TabIndex = 31;
      // 
      // getProjectsButton
      // 
      this.getProjectsButton.Location = new System.Drawing.Point(406, 122);
      this.getProjectsButton.Name = "getProjectsButton";
      this.getProjectsButton.Size = new System.Drawing.Size(125, 39);
      this.getProjectsButton.TabIndex = 32;
      this.getProjectsButton.Text = "Get projects";
      this.getProjectsButton.UseVisualStyleBackColor = true;
      this.getProjectsButton.Click += new System.EventHandler(this.getProjectsButton_Click);
      // 
      // startOverButton
      // 
      this.startOverButton.Location = new System.Drawing.Point(406, 383);
      this.startOverButton.Name = "startOverButton";
      this.startOverButton.Size = new System.Drawing.Size(125, 39);
      this.startOverButton.TabIndex = 33;
      this.startOverButton.Text = "Start over";
      this.startOverButton.UseVisualStyleBackColor = true;
      this.startOverButton.Click += new System.EventHandler(this.startOverButton_Click);
      // 
      // GroupBox1
      // 
      this.GroupBox1.Controls.Add(this.basicHttpRadioButton);
      this.GroupBox1.Controls.Add(this.wsHttpRadioButton);
      this.GroupBox1.Controls.Add(this.tcpRadioButton);
      this.GroupBox1.Location = new System.Drawing.Point(30, 12);
      this.GroupBox1.Name = "GroupBox1";
      this.GroupBox1.Size = new System.Drawing.Size(399, 54);
      this.GroupBox1.TabIndex = 41;
      this.GroupBox1.TabStop = false;
      this.GroupBox1.Text = "Select a binding";
      // 
      // basicHttpRadioButton
      // 
      this.basicHttpRadioButton.AutoSize = true;
      this.basicHttpRadioButton.Location = new System.Drawing.Point(257, 22);
      this.basicHttpRadioButton.Name = "basicHttpRadioButton";
      this.basicHttpRadioButton.Size = new System.Drawing.Size(133, 21);
      this.basicHttpRadioButton.TabIndex = 2;
      this.basicHttpRadioButton.Text = "BasicHttpBinding";
      this.basicHttpRadioButton.UseVisualStyleBackColor = true;
      // 
      // wsHttpRadioButton
      // 
      this.wsHttpRadioButton.AutoSize = true;
      this.wsHttpRadioButton.Location = new System.Drawing.Point(132, 22);
      this.wsHttpRadioButton.Name = "wsHttpRadioButton";
      this.wsHttpRadioButton.Size = new System.Drawing.Size(119, 21);
      this.wsHttpRadioButton.TabIndex = 1;
      this.wsHttpRadioButton.Text = "WsHttpBinding";
      this.wsHttpRadioButton.UseVisualStyleBackColor = true;
      // 
      // tcpRadioButton
      // 
      this.tcpRadioButton.AutoSize = true;
      this.tcpRadioButton.Checked = true;
      this.tcpRadioButton.Location = new System.Drawing.Point(7, 23);
      this.tcpRadioButton.Name = "tcpRadioButton";
      this.tcpRadioButton.Size = new System.Drawing.Size(119, 21);
      this.tcpRadioButton.TabIndex = 0;
      this.tcpRadioButton.TabStop = true;
      this.tcpRadioButton.Text = "NetTcpBinding";
      this.tcpRadioButton.UseVisualStyleBackColor = true;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(559, 465);
      this.Controls.Add(this.GroupBox1);
      this.Controls.Add(this.startOverButton);
      this.Controls.Add(this.getProjectsButton);
      this.Controls.Add(this.projectsListBox);
      this.Controls.Add(this.showRequestsButton);
      this.Controls.Add(this.addRequestButton);
      this.Controls.Add(this.cartLabel);
      this.Controls.Add(this.requestedProjectsListBox);
      this.Controls.Add(this.Label2);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Project Requests";
      this.GroupBox1.ResumeLayout(false);
      this.GroupBox1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.Label Label2;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    internal System.Windows.Forms.Button showRequestsButton;
    internal System.Windows.Forms.Button addRequestButton;
    internal System.Windows.Forms.Label cartLabel;
    internal System.Windows.Forms.ListBox requestedProjectsListBox;
    internal System.Windows.Forms.ListBox projectsListBox;
    internal System.Windows.Forms.Button getProjectsButton;
    internal System.Windows.Forms.Button startOverButton;
    internal System.Windows.Forms.GroupBox GroupBox1;
    internal System.Windows.Forms.RadioButton basicHttpRadioButton;
    internal System.Windows.Forms.RadioButton wsHttpRadioButton;
    internal System.Windows.Forms.RadioButton tcpRadioButton;
  }
}

