﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ContractorServiceLibrary
{
  public class ContractorService : IContractorService
  {
    private Project project = null;
    private List<Project> projects = null;
    private List<Project> requestedProjects = null;

    public List<Project> GetProjects()
    {
      projects = new List<Project>();
      requestedProjects = new List<Project>();

      project = new Project();
      project.ProjectName = "Kitchen remodel";
      project.MinimumCost = 15000M;
      projects.Add(project);

      project = new Project();
      project.ProjectName = "Bathroom remodel";
      project.MinimumCost = 7500M;
      projects.Add(project);

      project = new Project();
      project.ProjectName = "Interior painting";
      project.MinimumCost = 500M;
      projects.Add(project);

      project = new Project();
      project.ProjectName = "Exterior painting";
      project.MinimumCost = 3000M;
      projects.Add(project);

      project = new Project();
      project.ProjectName = "Flooring and carpeting";
      project.MinimumCost = 500M;
      projects.Add(project);

      try
      {
        return projects;
      }
      catch (Exception ex)
      {
        throw new FaultException(ex.Message);
      }
    }

    public void RequestProject(Project project)
    {
      try
      {
        requestedProjects.Add(project);
      }
      catch (Exception ex)
      {
        throw new FaultException(ex.Message);
      }
    }

    public List<Project> GetRequestedProjects()
    {
      try
      {
        return requestedProjects;
      }
      catch (Exception ex)
      {
        throw new FaultException(ex.Message);
      }
    }

    public void StartOver()
    {
      requestedProjects = new List<Project>();
    }

  }
}
