﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ContractorServiceLibrary
{
  [ServiceContract]
  public interface IContractorService
  {
    [OperationContract]
    List<Project> GetProjects();

    [OperationContract]
    void RequestProject(Project project);

    [OperationContract]
    List<Project> GetRequestedProjects();

    [OperationContract]
    void StartOver();
  }

  [DataContract]
  public class Project
  {
    [DataMember]
    public string ProjectName { get; set; }

    [DataMember]
    public decimal MinimumCost { get; set; }
  }

}
