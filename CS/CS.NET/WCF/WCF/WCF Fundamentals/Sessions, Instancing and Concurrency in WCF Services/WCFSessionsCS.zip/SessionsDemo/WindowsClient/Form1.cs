﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using WindowsClient.ContractorService;

namespace WindowsClient
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private Project project = null;
    private List<Project> projects = null;
    private List<Project> requestedProjects = null;
    private ContractorServiceClient proxy = null;

    private void CreateProxy()
    {
      if (tcpRadioButton.Checked == true)
      {
        proxy = new ContractorServiceClient("ContractorService_Tcp");
      }
      else if (wsHttpRadioButton.Checked == true)
      {
        proxy = new ContractorServiceClient("ContractorService_WsHttp");
      }
      else if (basicHttpRadioButton.Checked == true)
      {
        proxy = new ContractorServiceClient("ContractorService_BasicHttp");
      }
    }

    private void getProjectsButton_Click(object sender, EventArgs e)
    {
      CreateProxy();
      try
      {
        projects = proxy.GetProjects();
        foreach (Project project in projects)
        {
          projectsListBox.Items.Add(string.Format("{0} ({1:C})",
            project.ProjectName, project.MinimumCost));
        }
      }
      catch (FaultException faultEx)
      {
        MessageBox.Show(faultEx.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void addRequestButton_Click(object sender, EventArgs e)
    {
      project = new Project();
      project.ProjectName =
        projects[projectsListBox.SelectedIndex].ProjectName;
      project.MinimumCost =
        projects[projectsListBox.SelectedIndex].MinimumCost;

      try
      {
        proxy.RequestProject(project);

        MessageBox.Show(String.Format(
          "You requested {0}", project.ProjectName));
      }
      catch (FaultException faultEx)
      {
        MessageBox.Show(faultEx.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void showRequestsButton_Click(object sender, EventArgs e)
    {
      try
      {
        requestedProjects = proxy.GetRequestedProjects();

        requestedProjectsListBox.Items.Clear();
        foreach (Project project in requestedProjects)
        {
          requestedProjectsListBox.Items.Add(string.Format("{0} ({1:C})",
            project.ProjectName, project.MinimumCost));
        }
      }
      catch (FaultException faultEx)
      {
        MessageBox.Show(faultEx.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void startOverbutton_Click(object sender, EventArgs e)
    {
      requestedProjectsListBox.Items.Clear();
      CreateProxy();
      proxy.StartOver();
    }

  }
}
