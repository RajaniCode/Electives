﻿using System.Reflection;
using System.Security;

[assembly: AssemblyTitle("Valil.Chess.Engine")]
[assembly: AssemblyDescription("Engine for Valil.Chess")]
[assembly: AssemblyCompany("Valil")]
[assembly: AssemblyProduct("Valil.Chess")]
[assembly: AssemblyCopyright("Copyright © 2004-2006, Valentin Iliescu; Some parts Copyright © 2002, Peter Hunter")]
[assembly: AssemblyVersion("1.4.1.0")]
[assembly: AllowPartiallyTrustedCallersAttribute()]
[assembly: AssemblyFileVersion("1.4.1.0")]
