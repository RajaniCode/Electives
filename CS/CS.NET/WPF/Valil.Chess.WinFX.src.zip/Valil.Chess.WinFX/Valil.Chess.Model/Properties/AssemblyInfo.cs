﻿using System.Reflection;
using System.Security;

[assembly: AssemblyTitle("Valil.Chess.Model")]
[assembly: AssemblyDescription("Model for Valil.Chess")]
[assembly: AssemblyCompany("Valil")]
[assembly: AssemblyProduct("Valil.Chess")]
[assembly: AssemblyCopyright("Copyright © 2004-2006, Valentin Iliescu")]
[assembly: AssemblyVersion("1.7.3.0")]
[assembly: AllowPartiallyTrustedCallersAttribute()]
[assembly: AssemblyFileVersion("1.7.3.0")]
