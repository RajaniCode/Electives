﻿using System.Reflection;
using System.Security;

[assembly: AssemblyTitle("Valil.Chess.Opponents")]
[assembly: AssemblyDescription("The opponents for Valil.Chess")]
[assembly: AssemblyCompany("Valil")]
[assembly: AssemblyProduct("Valil.Chess")]
[assembly: AssemblyCopyright("Copyright © 2004-2006, Valentin Iliescu")]
[assembly: AssemblyVersion("1.3.2.0")]
[assembly: AllowPartiallyTrustedCallersAttribute()]
[assembly: AssemblyFileVersion("1.3.2.0")]
