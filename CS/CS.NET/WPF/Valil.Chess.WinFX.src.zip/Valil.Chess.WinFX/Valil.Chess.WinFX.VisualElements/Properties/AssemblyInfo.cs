#region Using directives

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Resources;
using System.Globalization;
using System.Windows;
using System.Runtime.InteropServices;
using System.Security;

#endregion

[assembly: AssemblyTitle("Valil.Chess.WinFX.VisualElements")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("VALIL")]
[assembly: AssemblyProduct("Valil.Chess.WinFX.VisualElements")]
[assembly: AssemblyCopyright("Copyright @ VALIL 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: AllowPartiallyTrustedCallersAttribute()]
[assembly: AssemblyVersion("2.2.*")]
