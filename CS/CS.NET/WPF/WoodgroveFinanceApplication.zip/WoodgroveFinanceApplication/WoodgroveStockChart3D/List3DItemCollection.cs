using System;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Collections.ObjectModel;

namespace WoodgroveFinanceStockChart3D
{

    public class List3DItemCollection : ObservableCollection<List3DItem>
    {
    }

}